from flask import Flask, jsonify, request
import sqlite3
from datetime import datetime, timedelta
from reportlab.lib.pagesizes import letter
from reportlab.pdfgen import canvas
import os

app = Flask(__name__)

# SQLite Database Setup
def init_db():
    conn = sqlite3.connect('library.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS borrowings 
                 (id INTEGER PRIMARY KEY, book_id INTEGER, member_id INTEGER, 
                  issue_date TEXT, return_date TEXT, fine REAL)''')
    conn.commit()
    conn.close()

# Calculate fine (Rs. 5 per day overdue)
def calculate_fine(issue_date, return_date):
    issue = datetime.strptime(issue_date, '%Y-%m-%d')
    due = issue + timedelta(days=14)  # 2-week borrowing period
    if return_date:
        ret = datetime.strptime(return_date, '%Y-%m-%d')
        if ret > due:
            days_overdue = (ret - due).days
            return days_overdue * 5.0
    return 0.0

# Generate PDF report
def generate_report(member_id):
    conn = sqlite3.connect('library.db')
    c = conn.cursor()
    c.execute("""SELECT book_id, issue_date, return_date 
                 FROM borrowings WHERE member_id=?""", (member_id,))
    borrowings = c.fetchall()
    conn.close()

    pdf_path = f"reports/report_member_{member_id}.pdf"
    c = canvas.Canvas(pdf_path, pagesize=letter)
    c.drawString(100, 750, f"Borrowing Report for Member {member_id}")
    y = 700

    for borrowing in borrowings:
        book_id, issue_date, return_date = borrowing
        fine = calculate_fine(issue_date, return_date) if return_date else calculate_fine(issue_date, str(datetime.today().date()))
        c.drawString(100, y, f"Book ID: {book_id}, Issue Date: {issue_date}, Fine: Rs. {fine}")
        y -= 20

    c.save()
    return pdf_path


# REST API Endpoints
@app.route('/api/fine', methods=['POST'])
def get_fine():
    data = request.json
    issue_date = data.get('issue_date')
    return_date = data.get('return_date')
    
    if not issue_date or not return_date:
        return jsonify({"error": "Missing required fields"}), 400
    
    fine = calculate_fine(issue_date, return_date)
    return jsonify({"fine": fine})

@app.route('/api/report/<int:member_id>', methods=['GET'])
def get_report(member_id):
    pdf_path = generate_report(member_id)
    return jsonify({"report_path": pdf_path})

if __name__ == '__main__':
    if not os.path.exists('reports'):
        os.makedirs('reports')
    init_db()
    app.run(port=5000, debug=True)
