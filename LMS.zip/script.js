const API_URL = "http://localhost:5000/api";

// Add a new book
function addBook() {
    const title = document.getElementById("book-title").value;
    const author = document.getElementById("book-author").value;
    const copies = document.getElementById("book-copies").value;
    
    fetch(`${API_URL}/books`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, author, total_copies: copies })
    })
    .then(response => response.json())
    .then(data => {
        alert("Book added successfully!");
        document.getElementById("book-title").value = "";
        document.getElementById("book-author").value = "";
        document.getElementById("book-copies").value = "";
        loadBooks();
    });
}

// Load books from database
function loadBooks() {
    fetch(`${API_URL}/books`)
    .then(response => response.json())
    .then(data => {
        const bookList = document.getElementById("book-list");
        bookList.innerHTML = "";
        data.forEach(book => {
            const li = document.createElement("li");
            li.textContent = `${book.id}: ${book.title} by ${book.author} (Copies: ${book.available_copies})`;
            bookList.appendChild(li);
        });
    });
}

// Register a new member
function registerMember() {
    const name = document.getElementById("member-name").value;
    const email = document.getElementById("member-email").value;
    const phone = document.getElementById("member-phone").value;
    const address = document.getElementById("member-address").value;
    
    fetch(`${API_URL}/members`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, phone, address })
    })
    .then(response => response.json())
    .then(data => {
        alert("Member registered successfully!");
        document.getElementById("member-name").value = "";
        document.getElementById("member-email").value = "";
        document.getElementById("member-phone").value = "";
        document.getElementById("member-address").value = "";
        loadMembers();
    });
}

// Load members from database
function loadMembers() {
    fetch(`${API_URL}/members`)
    .then(response => response.json())
    .then(data => {
        const memberList = document.getElementById("member-list");
        memberList.innerHTML = "";
        data.forEach(member => {
            const li = document.createElement("li");
            li.textContent = `${member.id}: ${member.name} (${member.email})`;
            memberList.appendChild(li);
        });
    });
}

// Borrow a book
function borrowBook() {
    const bookId = document.getElementById("borrow-book-id").value;
    const memberId = document.getElementById("borrow-member-id").value;
    
    fetch(`${API_URL}/borrow`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ book_id: bookId, member_id: memberId })
    })
    .then(response => response.json())
    .then(data => {
        alert("Book borrowed successfully!");
        document.getElementById("borrow-book-id").value = "";
        document.getElementById("borrow-member-id").value = "";
        loadBooks();
    });
}

// Return a book
function returnBook() {
    const bookId = document.getElementById("return-book-id").value;
    
    fetch(`${API_URL}/return`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ book_id: bookId })
    })
    .then(response => response.json())
    .then(data => {
        alert("Book returned successfully!");
        document.getElementById("return-book-id").value = "";
        loadBooks();
    });
}

// Initial data load
window.onload = function() {
    loadBooks();
    loadMembers();
};
